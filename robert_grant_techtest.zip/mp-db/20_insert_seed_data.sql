INSERT INTO product
(name, price, product_code)
VALUES
('Lavender heart', 9.25, '001'),
('Personalised cufflinks', 45.00, '002'),
('Kids T-shirt', 19.95, '003');
